import { useState, useRef, useEffect, useCallback } from 'react'

// ─── Theme ────────────────────────────────────────────────────────────────────
const T = {
  windowBg:    'rgba(14,20,52,0.82)',
  panelBg:     'rgba(18,26,65,0.88)',
  sidebarBg:   'rgba(20,28,72,0.92)',
  tabBg:       'rgba(26,36,82,0.75)',
  tabActive:   'rgba(48,72,160,0.90)',
  tabHover:    'rgba(36,52,110,0.85)',
  compBg:      'rgba(20,30,72,0.70)',
  compHover:   'rgba(30,44,96,0.85)',
  btnBg:       'rgba(38,62,158,0.92)',
  btnHover:    'rgba(52,84,188,1)',
  btnPress:    'rgba(28,48,128,1)',
  border:      'rgba(70,105,210,0.50)',
  borderFocus: 'rgba(110,160,255,0.80)',
  borderActive:'rgba(90,140,255,0.70)',
  text:        '#e2e8ff',
  textSub:     '#a0b4e0',
  textMuted:   '#5a72b0',
  textAccent:  '#80aaff',
  textOwner:   '#f5a855',
  textSuccess: '#52d48a',
  textError:   '#f05a5a',
  textWarn:    '#f0c040',
  togOff:      'rgba(36,46,100,0.9)',
  togOn:       'rgba(60,120,255,0.95)',
  sliderTrack: 'rgba(24,34,82,0.9)',
  sliderFill:  'linear-gradient(90deg,#4a7aff,#7ab0ff)',
  glow:        '0 0 18px rgba(80,130,255,0.28)',
  glowStrong:  '0 0 28px rgba(80,130,255,0.50)',
  shadow:      '0 8px 40px rgba(0,0,10,0.55)',
  notifSuccess:'rgba(40,160,90,0.92)',
  notifWarn:   'rgba(190,145,30,0.92)',
  notifError:  'rgba(190,50,50,0.92)',
  notifInfo:   'rgba(40,90,200,0.92)',
}

// ─── Glassmorphic window styles ───────────────────────────────────────────────
const glass = (extra = ''): React.CSSProperties => ({
  background: T.windowBg,
  backdropFilter: 'blur(24px) saturate(1.6)',
  WebkitBackdropFilter: 'blur(24px) saturate(1.6)',
  border: `1.5px solid ${T.border}`,
  borderRadius: 14,
  boxShadow: `${T.shadow}, inset 0 1px 0 rgba(255,255,255,0.06)`,
})

// ─── Types ────────────────────────────────────────────────────────────────────
type TabId = 'combat'|'hitbox'|'optimization'|'visual'

interface NotifItem {
  id: number
  title: string
  message: string
  type: 'success'|'warning'|'error'|'info'
}

// ─── Hooks ───────────────────────────────────────────────────────────────────
function useDrag(ref: React.RefObject<HTMLDivElement | null>) {
  const pos = useRef({ x: 0, y: 0 })
  const start = useRef({ mx: 0, my: 0, ex: 0, ey: 0 })
  const dragging = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const onDown = (e: MouseEvent) => {
      dragging.current = true
      start.current = { mx: e.clientX, my: e.clientY, ex: pos.current.x, ey: pos.current.y }
      e.preventDefault()
    }
    const onMove = (e: MouseEvent) => {
      if (!dragging.current) return
      pos.current = {
        x: start.current.ex + e.clientX - start.current.mx,
        y: start.current.ey + e.clientY - start.current.my,
      }
      if (ref.current) {
        ref.current.style.transform = `translate(${pos.current.x}px,${pos.current.y}px)`
      }
    }
    const onUp = () => { dragging.current = false }
    el.addEventListener('mousedown', onDown)
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => {
      el.removeEventListener('mousedown', onDown)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
  }, [])
}

// ─── Sub-components ───────────────────────────────────────────────────────────
function Divider() {
  return <div style={{ height:1, background:`linear-gradient(90deg,transparent,${T.border},transparent)`, margin:'4px 0' }} />
}

function Label({ text, color }: { text: string; color?: string }) {
  return <p style={{ margin:0, fontSize:11, color: color||T.textSub, fontWeight:500 }}>{text}</p>
}

function Button({ label, onClick, accent }: { label: string; onClick?: () => void; accent?: boolean }) {
  const [hover, setHover] = useState(false)
  const [press, setPress] = useState(false)
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false) }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={{
        width:'100%', padding:'8px 12px', borderRadius:8,
        background: press ? T.btnPress : hover ? T.btnHover : T.btnBg,
        border: `1.5px solid ${hover ? T.borderFocus : T.border}`,
        color: T.text, fontSize:12, fontWeight:700,
        fontFamily:'inherit', cursor:'pointer',
        boxShadow: hover ? T.glowStrong : T.glow,
        transition:'all 0.15s ease', letterSpacing:'0.3px',
        transform: press ? 'scale(0.97)' : hover ? 'scale(1.01)' : 'scale(1)',
      }}
    >{label}</button>
  )
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
      <span style={{ fontSize:12, color:T.textSub, fontWeight:600 }}>{label}</span>
      <div
        onClick={() => onChange(!value)}
        style={{
          width:42, height:22, borderRadius:11, cursor:'pointer',
          background: value ? T.togOn : T.togOff,
          border:`1.5px solid ${value ? T.borderFocus : T.border}`,
          position:'relative', transition:'all 0.2s ease',
          boxShadow: value ? '0 0 12px rgba(80,140,255,0.45)' : 'none',
          flexShrink:0,
        }}
      >
        <div style={{
          position:'absolute', top:2,
          left: value ? 20 : 2,
          width:14, height:14, borderRadius:'50%',
          background:'#fff', transition:'left 0.2s ease',
          boxShadow:'0 1px 4px rgba(0,0,0,0.4)',
        }} />
      </div>
    </div>
  )
}

function Slider({ label, value, min, max, step, suffix, onChange }:{
  label:string; value:number; min:number; max:number;
  step?:number; suffix?:string; onChange:(v:number)=>void
}) {
  const pct = ((value-min)/(max-min))*100
  const [hover, setHover] = useState(false)
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:11, color:T.textSub, fontWeight:600 }}>{label}</span>
        <span style={{ fontSize:11, color:T.textAccent, fontWeight:700, fontFamily:'JetBrains Mono,monospace' }}>
          {value}{suffix||''}
        </span>
      </div>
      <div style={{ position:'relative', height:8 }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        <div style={{
          position:'absolute', inset:0, borderRadius:4,
          background:T.sliderTrack, border:`1px solid ${T.border}`,
        }} />
        <div style={{
          position:'absolute', left:0, top:0, bottom:0,
          width:`${pct}%`, borderRadius:4,
          background:T.sliderFill,
          boxShadow:'0 0 8px rgba(80,130,255,0.5)',
          transition:'width 0.1s ease',
        }} />
        <input type="range" min={min} max={max} step={step||1} value={value}
          onChange={e => onChange(Number(e.target.value))}
          style={{
            position:'absolute', inset:0, width:'100%', height:'100%',
            opacity:0, cursor:'pointer', margin:0,
          }}
        />
        <div style={{
          position:'absolute', top:'50%', left:`${pct}%`,
          transform:'translate(-50%,-50%)',
          width: hover ? 16 : 13, height: hover ? 16 : 13,
          borderRadius:'50%', background:'#fff',
          border:`2px solid rgba(80,130,255,0.8)`,
          boxShadow:'0 2px 6px rgba(0,0,0,0.4)',
          pointerEvents:'none', transition:'all 0.15s ease',
        }} />
      </div>
    </div>
  )
}

function Textbox({ label, placeholder, value, onChange }: {
  label:string; placeholder:string; value:string; onChange:(v:string)=>void
}) {
  const [focus, setFocus] = useState(false)
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
      <span style={{ fontSize:11, color:T.textSub, fontWeight:600 }}>{label}</span>
      <div style={{
        display:'flex', alignItems:'center', borderRadius:7,
        background:'rgba(14,20,52,0.75)',
        border:`1.5px solid ${focus ? T.borderFocus : T.border}`,
        boxShadow: focus ? '0 0 12px rgba(80,140,255,0.25)' : 'none',
        transition:'all 0.15s ease', overflow:'hidden',
      }}>
        <input type="text" value={value} placeholder={placeholder}
          onChange={e => onChange(e.target.value)}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex:1, padding:'7px 10px', background:'transparent',
            border:'none', outline:'none', color:T.text,
            fontSize:12, fontFamily:'inherit', fontWeight:500,
          }}
        />
        {value && (
          <button onClick={() => onChange('')}
            style={{ padding:'0 8px', background:'transparent', border:'none', color:T.textMuted, cursor:'pointer', fontSize:16, lineHeight:1 }}>
            ×
          </button>
        )}
      </div>
    </div>
  )
}

function Dropdown({ label, items, value, onChange }: {
  label:string; items:string[]; value:string; onChange:(v:string)=>void
}) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const filtered = items.filter(i => i.toLowerCase().includes(search.toLowerCase()))

  return (
    <div style={{ position:'relative', display:'flex', flexDirection:'column', gap:4 }}>
      <span style={{ fontSize:11, color:T.textSub, fontWeight:600 }}>{label}</span>
      <button onClick={() => setOpen(!open)} style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        padding:'7px 10px', borderRadius:7, cursor:'pointer',
        background:'rgba(14,20,52,0.75)',
        border:`1.5px solid ${open ? T.borderFocus : T.border}`,
        color: value ? T.text : T.textMuted,
        fontSize:12, fontFamily:'inherit', fontWeight:500,
        transition:'all 0.15s ease',
      }}>
        <span>{value||'Select...'}</span>
        <span style={{ color:T.textMuted, transform: open ? 'rotate(180deg)' : 'none', transition:'0.2s', fontSize:10 }}>▾</span>
      </button>
      {open && (
        <div style={{
          position:'absolute', top:'calc(100% + 4px)', left:0, right:0, zIndex:100,
          background:'rgba(16,22,58,0.98)', backdropFilter:'blur(16px)',
          border:`1.5px solid ${T.border}`, borderRadius:8,
          overflow:'hidden', boxShadow:'0 8px 32px rgba(0,0,0,0.5)',
        }}>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search..."
            style={{
              width:'100%', padding:'7px 10px', background:'rgba(14,20,52,0.6)',
              border:'none', borderBottom:`1px solid ${T.border}`,
              color:T.text, fontSize:11, fontFamily:'inherit', outline:'none',
            }}
          />
          <div style={{ maxHeight:120, overflowY:'auto' }}>
            {filtered.map(item => (
              <div key={item}
                onClick={() => { onChange(item); setOpen(false); setSearch('') }}
                style={{
                  padding:'7px 10px', fontSize:12, cursor:'pointer',
                  background: value===item ? 'rgba(48,72,160,0.6)' : 'transparent',
                  color: value===item ? T.text : T.textSub,
                  transition:'background 0.1s',
                }}
                onMouseEnter={e => { if(value!==item)(e.target as HTMLDivElement).style.background='rgba(36,52,110,0.7)' }}
                onMouseLeave={e => { (e.target as HTMLDivElement).style.background = value===item?'rgba(48,72,160,0.6)':'transparent' }}
              >{item}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function Keybind({ label, value, onChange }: { label:string; value:string; onChange:(v:string)=>void }) {
  const [listening, setListening] = useState(false)
  useEffect(() => {
    if (!listening) return
    const handler = (e: KeyboardEvent) => {
      onChange(e.key.toUpperCase())
      setListening(false)
    }
    window.addEventListener('keydown', handler, { once: true })
    return () => window.removeEventListener('keydown', handler)
  }, [listening])
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
      <span style={{ fontSize:12, color:T.textSub, fontWeight:600 }}>{label}</span>
      <button
        onClick={() => setListening(true)}
        onContextMenu={e => { e.preventDefault(); onChange('None') }}
        style={{
          padding:'4px 14px', borderRadius:6, cursor:'pointer',
          background: listening ? 'rgba(48,72,160,0.9)' : T.compBg,
          border:`1.5px solid ${listening ? T.borderFocus : T.border}`,
          color: listening ? '#fff' : T.textAccent,
          fontSize:11, fontWeight:700, fontFamily:'JetBrains Mono,monospace',
          transition:'all 0.15s', minWidth:72, textAlign:'center',
          boxShadow: listening ? '0 0 14px rgba(80,140,255,0.4)' : 'none',
        }}
      >{listening ? '...' : value}</button>
    </div>
  )
}

function ColorPicker({ label, value, onChange }: { label:string; value:string; onChange:(v:string)=>void }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
      <span style={{ fontSize:12, color:T.textSub, fontWeight:600 }}>{label}</span>
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontSize:11, color:T.textMuted, fontFamily:'JetBrains Mono,monospace' }}>{value}</span>
        <label style={{ cursor:'pointer', position:'relative', display:'flex' }}>
          <div style={{
            width:32, height:22, borderRadius:6, border:`1.5px solid ${T.border}`,
            background:value, boxShadow:`0 0 8px ${value}55`,
          }} />
          <input type="color" value={value} onChange={e => onChange(e.target.value)}
            style={{ position:'absolute', opacity:0, width:0, height:0 }} />
        </label>
      </div>
    </div>
  )
}

function ProgressBar({ label, value, max, suffix }: { label:string; value:number; max:number; suffix?:string }) {
  const pct = Math.round((value/max)*100)
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
      <div style={{ display:'flex', justifyContent:'space-between' }}>
        <span style={{ fontSize:11, color:T.textSub, fontWeight:600 }}>{label}</span>
        <span style={{ fontSize:11, color:T.textAccent, fontWeight:700, fontFamily:'JetBrains Mono,monospace' }}>{pct}{suffix||'%'}</span>
      </div>
      <div style={{ height:8, borderRadius:4, background:T.sliderTrack, border:`1px solid ${T.border}`, overflow:'hidden' }}>
        <div style={{ height:'100%', width:`${pct}%`, borderRadius:4, background:T.sliderFill, boxShadow:'0 0 8px rgba(80,130,255,0.5)', transition:'width 0.4s ease' }} />
      </div>
    </div>
  )
}

function Section({ title, children, defaultOpen = true }: { title:string; children:React.ReactNode; defaultOpen?:boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div style={{ borderRadius:10, border:`1px solid ${T.border}`, background:'rgba(16,24,60,0.55)', overflow:'visible' }}>
      <div onClick={() => setOpen(!open)} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 12px', cursor:'pointer', userSelect:'none' }}>
        <span style={{ fontSize:11, fontWeight:800, color:'rgba(140,165,240,0.9)', letterSpacing:'0.8px', textTransform:'uppercase' }}>{title}</span>
        <span style={{ color:T.textMuted, fontSize:10, transform: open?'rotate(0deg)':'rotate(-90deg)', transition:'0.2s' }}>▾</span>
      </div>
      {open && (
        <>
          <div style={{ height:1, background:`linear-gradient(90deg,transparent,${T.border},transparent)` }} />
          <div style={{ padding:'10px 12px', display:'flex', flexDirection:'column', gap:10 }}>
            {children}
          </div>
        </>
      )}
    </div>
  )
}

// ─── Tab content panels ───────────────────────────────────────────────────────
function CombatPanel() {
  const [silentAim, setSilentAim] = useState(false)
  const [fov, setFov] = useState(120)
  const [aimPart, setAimPart] = useState('Head')
  const [teamCheck, setTeamCheck] = useState(true)
  const [aimbot, setAimbot] = useState(false)
  const [smoothing, setSmoothing] = useState(42)
  const [keyText, setKeyText] = useState('')

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <Section title="Silent Aim">
        <Toggle label="Silent Aim" value={silentAim} onChange={setSilentAim} />
        <Toggle label="Team Check" value={teamCheck} onChange={setTeamCheck} />
        <Slider label="FOV Radius" value={fov} min={1} max={500} suffix="px" onChange={setFov} />
        <Dropdown label="Aim Part" items={['Head','Torso','HumanoidRootPart','LeftArm','RightArm']} value={aimPart} onChange={setAimPart} />
        <Button label="--== Apply Silent Aim ==--" />
      </Section>
      <Section title="Aimbot">
        <Toggle label="Aimbot" value={aimbot} onChange={setAimbot} />
        <Slider label="Smoothing" value={smoothing} min={1} max={100} suffix="%" onChange={setSmoothing} />
        <Keybind label="Toggle Key" value={keyText||'E'} onChange={setKeyText} />
      </Section>
      <Section title="Knife Settings">
        <Textbox label="Knife Name" placeholder="Knife Silent Aim" value="" onChange={() => {}} />
        <Button label="Equip Knife" />
        <Divider />
        <Label text="Version: 690  |  Script: CapybaraScripts Hub" />
      </Section>
    </div>
  )
}

function HitboxPanel() {
  const [enabled, setEnabled] = useState(false)
  const [viz, setViz] = useState(false)
  const [size, setSize] = useState(5)
  const [color, setColor] = useState('#50aaff')
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <Section title="Hitbox Settings">
        <Toggle label="Hitbox Expander" value={enabled} onChange={setEnabled} />
        <Toggle label="Visualize Hitbox" value={viz} onChange={setViz} />
        <Slider label="Hitbox Size" value={size} min={1} max={20} step={0.5} suffix="x" onChange={setSize} />
        <ColorPicker label="Hitbox Color" value={color} onChange={setColor} />
        <Button label="Apply Hitbox" />
      </Section>
      <Section title="Filters">
        <Toggle label="Team Check" value={true} onChange={() => {}} />
        <Toggle label="Ignore Self" value={true} onChange={() => {}} />
        <Dropdown label="Target Team" items={['All','Enemy','Friendly']} value="Enemy" onChange={() => {}} />
      </Section>
    </div>
  )
}

function OptPanel() {
  const [shadows, setShadows] = useState(true)
  const [particles, setParticles] = useState(false)
  const [textures, setTextures] = useState(false)
  const [fpsCap, setFpsCap] = useState(60)
  const [mem, setMem] = useState(42)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <Section title="Performance">
        <Toggle label="Disable Shadows" value={shadows} onChange={setShadows} />
        <Toggle label="Disable Particles" value={particles} onChange={setParticles} />
        <Toggle label="Low Textures" value={textures} onChange={setTextures} />
        <Slider label="FPS Cap" value={fpsCap} min={15} max={240} step={5} suffix=" fps" onChange={setFpsCap} />
      </Section>
      <Section title="Memory">
        <ProgressBar label="Memory Usage" value={mem} max={100} suffix="%" />
        <ProgressBar label="GPU Load" value={28} max={100} suffix="%" />
        <Button label="Garbage Collect" onClick={() => setMem(Math.max(5, mem - 8))} />
      </Section>
    </div>
  )
}

function VisualPanel() {
  const [esp, setEsp] = useState(false)
  const [names, setNames] = useState(false)
  const [tracers, setTracers] = useState(false)
  const [espColor, setEspColor] = useState('#50aaff')
  const [key, setKey] = useState('X')
  const [brightness, setBrightness] = useState(50)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
      <Section title="ESP">
        <Toggle label="Player ESP" value={esp} onChange={setEsp} />
        <Toggle label="Name Tags" value={names} onChange={setNames} />
        <Toggle label="Tracers" value={tracers} onChange={setTracers} />
        <ColorPicker label="ESP Color" value={espColor} onChange={setEspColor} />
        <Keybind label="Toggle ESP" value={key} onChange={setKey} />
      </Section>
      <Section title="Environment">
        <Slider label="Brightness" value={brightness} min={0} max={100} suffix="%" onChange={setBrightness} />
        <Dropdown label="Sky" items={['Default','Night','Sunset','Space','Custom']} value="Default" onChange={() => {}} />
        <Button label="Apply Visual" />
      </Section>
    </div>
  )
}

// ─── Notification Toast ───────────────────────────────────────────────────────
function NotifToast({ notif, onDone }: { notif: NotifItem; onDone: () => void }) {
  const [visible, setVisible] = useState(false)
  const [progress, setProgress] = useState(100)

  useEffect(() => {
    requestAnimationFrame(() => setVisible(true))
    const start = Date.now()
    const dur = 4000
    const tick = setInterval(() => {
      const elapsed = Date.now() - start
      setProgress(Math.max(0, 100 - (elapsed / dur) * 100))
      if (elapsed >= dur) {
        clearInterval(tick)
        setVisible(false)
        setTimeout(onDone, 350)
      }
    }, 32)
    return () => clearInterval(tick)
  }, [])

  const accentMap = {
    success: T.notifSuccess, warning: T.notifWarn,
    error: T.notifError, info: T.notifInfo,
  }
  const accent = accentMap[notif.type]

  return (
    <div style={{
      display:'flex', flexDirection:'column', overflow:'hidden',
      borderRadius:10, border:`1.5px solid ${T.border}`,
      background:'rgba(14,20,52,0.95)', backdropFilter:'blur(20px)',
      boxShadow:'0 6px 28px rgba(0,0,0,0.5)',
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateX(0)' : 'translateX(120%)',
      transition:'all 0.32s cubic-bezier(0.34,1.56,0.64,1)',
      marginBottom:8,
    }}>
      <div style={{ display:'flex', gap:10, padding:'10px 12px', alignItems:'flex-start' }}>
        <div style={{ width:4, alignSelf:'stretch', borderRadius:2, background:accent, flexShrink:0 }} />
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:12, fontWeight:800, color:T.text, marginBottom:2 }}>{notif.title}</div>
          <div style={{ fontSize:11, color:T.textSub, lineHeight:1.4 }}>{notif.message}</div>
        </div>
      </div>
      <div style={{ height:3, background:'rgba(255,255,255,0.07)' }}>
        <div style={{ height:'100%', width:`${progress}%`, background:accent, transition:'width 0.03s linear', borderRadius:2 }} />
      </div>
    </div>
  )
}

// ─── Key System Modal ─────────────────────────────────────────────────────────
function KeySystemModal({ onSuccess, onClose }: { onSuccess: () => void; onClose: () => void }) {
  const [key, setKey] = useState('')
  const [status, setStatus] = useState<'idle'|'loading'|'success'|'error'>('idle')
  const [shake, setShake] = useState(false)

  const verify = () => {
    setStatus('loading')
    setTimeout(() => {
      if (key === 'CAPYBARA-FREE-2025' || key === 'OWNER') {
        setStatus('success')
        setTimeout(onSuccess, 800)
      } else {
        setStatus('error')
        setShake(true)
        setTimeout(() => { setShake(false); setStatus('idle') }, 700)
      }
    }, 900)
  }

  return (
    <div style={{
      position:'fixed', inset:0, zIndex:200,
      display:'flex', alignItems:'center', justifyContent:'center',
      background:'rgba(4,8,24,0.75)', backdropFilter:'blur(8px)',
    }}>
      <div style={{
        width:340, borderRadius:14,
        ...glass(),
        background:'rgba(12,18,50,0.96)',
        padding:'24px 22px 20px',
        animation: shake ? 'shake 0.4s ease' : 'scaleIn 0.35s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
        <style>{`
          @keyframes scaleIn { from { opacity:0; transform:scale(0.85) } to { opacity:1; transform:scale(1) } }
          @keyframes shake {
            0%,100% { transform:translateX(0) }
            20% { transform:translateX(-8px) }
            40% { transform:translateX(8px) }
            60% { transform:translateX(-5px) }
            80% { transform:translateX(5px) }
          }
        `}</style>
        <div style={{ textAlign:'center', marginBottom:16 }}>
          <div style={{ fontSize:28, marginBottom:6 }}>🔑</div>
          <div style={{ fontSize:15, fontWeight:800, color:T.text }}>Key System</div>
          <div style={{ fontSize:11, color:T.textSub, marginTop:2 }}>Enter your key to access the hub</div>
        </div>
        <div style={{ marginBottom:10 }}>
          <div style={{
            display:'flex', borderRadius:8,
            background:'rgba(14,20,52,0.75)',
            border:`1.5px solid ${status==='error'?T.textError:status==='success'?T.textSuccess:T.border}`,
            overflow:'hidden', transition:'all 0.15s',
          }}>
            <input value={key} onChange={e => setKey(e.target.value)}
              placeholder="CAPYBARA-FREE-2025"
              onKeyDown={e => e.key==='Enter' && verify()}
              style={{
                flex:1, padding:'8px 12px', background:'transparent',
                border:'none', outline:'none', color:T.text,
                fontSize:12, fontFamily:'JetBrains Mono,monospace',
              }}
            />
          </div>
        </div>
        {status==='error' && <p style={{ fontSize:11, color:T.textError, margin:'0 0 10px', textAlign:'center' }}>✗ Invalid key. Try again.</p>}
        {status==='success' && <p style={{ fontSize:11, color:T.textSuccess, margin:'0 0 10px', textAlign:'center' }}>✓ Key accepted! Loading...</p>}
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={verify} disabled={status==='loading'}
            style={{
              flex:1, padding:'9px', borderRadius:8,
              background:T.btnBg, border:`1.5px solid ${T.border}`,
              color:'#fff', fontSize:12, fontWeight:700,
              fontFamily:'inherit', cursor:'pointer', transition:'all 0.15s',
            }}>
            {status==='loading' ? '⟳ Verifying...' : 'Verify'}
          </button>
          <button onClick={onClose}
            style={{
              padding:'9px 16px', borderRadius:8,
              background:'rgba(36,46,100,0.7)', border:`1.5px solid ${T.border}`,
              color:T.textSub, fontSize:12, fontWeight:600,
              fontFamily:'inherit', cursor:'pointer',
            }}>Skip</button>
        </div>
        <div style={{ display:'flex', gap:6, marginTop:8 }}>
          <button style={{
            flex:1, padding:'6px', borderRadius:7,
            background:'rgba(88,101,242,0.25)', border:'1.5px solid rgba(88,101,242,0.5)',
            color:'rgba(150,160,255,0.9)', fontSize:11, fontWeight:700,
            fontFamily:'inherit', cursor:'pointer',
          }}>Discord</button>
          <button style={{
            flex:1, padding:'6px', borderRadius:7,
            background:'rgba(40,150,80,0.2)', border:'1.5px solid rgba(60,180,100,0.4)',
            color:'rgba(100,220,140,0.9)', fontSize:11, fontWeight:700,
            fontFamily:'inherit', cursor:'pointer',
          }}>Get Key</button>
        </div>
      </div>
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
const TABS: { id: TabId; label: string; icon: string }[] = [
  { id:'combat',       label:'Combat',          icon:'⚔' },
  { id:'hitbox',       label:'Hitbox Expander',  icon:'⬡' },
  { id:'optimization', label:'Optimization',     icon:'⚙' },
  { id:'visual',       label:'Visual',           icon:'👁' },
]

let notifIdCounter = 0

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('combat')
  const [minimized, setMinimized] = useState(false)
  const [showKeySystem, setShowKeySystem] = useState(true)
  const [notifs, setNotifs] = useState<NotifItem[]>([])
  const windowRef = useRef<HTMLDivElement>(null)
  const topBarRef = useRef<HTMLDivElement>(null)

  // Drag on topbar
  const pos = useRef({ x: 0, y: 0 })
  const start = useRef({ mx: 0, my: 0, ex: 0, ey: 0 })
  const dragging = useRef(false)

  useEffect(() => {
    const el = topBarRef.current
    if (!el) return
    const onDown = (e: MouseEvent) => {
      dragging.current = true
      start.current = { mx: e.clientX, my: e.clientY, ex: pos.current.x, ey: pos.current.y }
      e.preventDefault()
    }
    const onMove = (e: MouseEvent) => {
      if (!dragging.current) return
      pos.current = { x: start.current.ex + e.clientX - start.current.mx, y: start.current.ey + e.clientY - start.current.my }
      if (windowRef.current) windowRef.current.style.transform = `translate(calc(-50% + ${pos.current.x}px), calc(-50% + ${pos.current.y}px))`
    }
    const onUp = () => { dragging.current = false }
    el.addEventListener('mousedown', onDown)
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => { el.removeEventListener('mousedown', onDown); window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp) }
  }, [])

  const addNotif = useCallback((title: string, message: string, type: NotifItem['type'] = 'info') => {
    const id = ++notifIdCounter
    setNotifs(prev => [...prev, { id, title, message, type }])
  }, [])

  const removeNotif = useCallback((id: number) => {
    setNotifs(prev => prev.filter(n => n.id !== id))
  }, [])

  return (
    <div style={{
      width:'100vw', height:'100vh', overflow:'hidden',
      background:'linear-gradient(135deg,#060c22 0%,#0c1438 50%,#080f2a 100%)',
      position:'relative', fontFamily:'Nunito,sans-serif',
      display:'flex', alignItems:'center', justifyContent:'center',
    }}>
      {/* Ambient glow blobs */}
      <div style={{ position:'absolute', width:400, height:400, borderRadius:'50%', background:'rgba(40,80,200,0.07)', top:'10%', left:'15%', filter:'blur(80px)', pointerEvents:'none' }} />
      <div style={{ position:'absolute', width:350, height:350, borderRadius:'50%', background:'rgba(80,40,180,0.06)', bottom:'15%', right:'20%', filter:'blur(70px)', pointerEvents:'none' }} />

      {/* ── Roblox Game Chrome (top HUD bar) ── */}
      <div style={{
        position:'absolute', top:0, left:0, right:0, height:44,
        background:'rgba(10,16,40,0.70)', backdropFilter:'blur(12px)',
        borderBottom:`1px solid ${T.border}`, display:'flex',
        alignItems:'center', justifyContent:'center', zIndex:5, gap:8,
        userSelect:'none',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <div style={{ width:28, height:28, borderRadius:6, background:'rgba(36,50,120,0.8)', border:`1px solid ${T.border}`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, color:T.textSub }}>3</div>
        </div>
        <div style={{ position:'absolute', left:'50%', transform:'translateX(-50%)', display:'flex', flexDirection:'column', alignItems:'center', lineHeight:1.2 }}>
          <span style={{ fontSize:13, fontWeight:800, color:T.text }}>Murderer Mystery 2</span>
          <span style={{ fontSize:10, color:T.textMuted }}>By CapybaraScripts</span>
        </div>
        <div style={{ marginLeft:'auto', marginRight:12, display:'flex', alignItems:'center', gap:6 }}>
          <span style={{ fontSize:10, color:T.textMuted, fontFamily:'JetBrains Mono,monospace' }}>104 FPS</span>
          <button
            onClick={() => addNotif('CapybaraUI', 'Notification demo!', 'success')}
            style={{
              padding:'4px 10px', borderRadius:6, fontSize:10, fontWeight:700,
              background:T.btnBg, border:`1px solid ${T.border}`,
              color:'#fff', cursor:'pointer', fontFamily:'inherit',
            }}
          >+ Notify</button>
        </div>
      </div>

      {/* ── Main UI Window ── */}
      <div ref={windowRef} style={{
        position:'absolute', top:'50%', left:'50%',
        transform:'translate(-50%,-50%)',
        width:620, zIndex:10,
        animation:'windowOpen 0.4s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
        <style>{`
          @keyframes windowOpen {
            from { opacity:0; transform:translate(-50%,-50%) scale(0.82) }
            to   { opacity:1; transform:translate(-50%,-50%) scale(1) }
          }
        `}</style>

        {/* Window glass frame */}
        <div style={{
          ...glass(),
          overflow:'hidden',
          display:'flex', flexDirection:'column',
          transition:'all 0.28s cubic-bezier(0.4,0,0.2,1)',
        }}>

          {/* ── Top Bar ── */}
          <div ref={topBarRef} style={{
            height:38, display:'flex', alignItems:'center',
            padding:'0 12px', gap:10, cursor:'grab',
            background:'rgba(16,24,60,0.80)',
            borderBottom:`1px solid ${T.border}`,
            userSelect:'none', flexShrink:0,
          }}>
            {/* Window controls */}
            {[
              { color:'#ef5350', symbol:'×', action: () => addNotif('Window','Closed (demo only)','warning') },
              { color:'#66bb6a', symbol:'□', action: () => {} },
              { color:'#ffa726', symbol:'–', action: () => setMinimized(m => !m) },
            ].map(({ color, symbol, action }) => (
              <button key={symbol} onClick={action}
                style={{
                  width:18, height:18, borderRadius:'50%',
                  background:color, border:'none', cursor:'pointer',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontSize:12, color:'rgba(0,0,0,0.6)', fontWeight:900,
                  lineHeight:1, transition:'filter 0.1s', flexShrink:0,
                }}
                onMouseEnter={e => (e.currentTarget.style.filter='brightness(1.2)')}
                onMouseLeave={e => (e.currentTarget.style.filter='brightness(1)')}
              >{symbol}</button>
            ))}
            <div style={{ flex:1, textAlign:'center', pointerEvents:'none' }}>
              <span style={{ fontSize:13, fontWeight:800, color:T.text }}>CapybaraScripts Hub</span>
              <span style={{ fontSize:10, color:T.textMuted, marginLeft:8 }}>v690</span>
            </div>
            <div style={{ width:54 }} />
          </div>

          {/* ── Body ── */}
          {!minimized && (
            <div style={{ display:'flex', height:390 }}>

              {/* ── Left Info + Content Panel ── */}
              <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>

                {/* Player info strip */}
                <div style={{
                  display:'flex', alignItems:'center', gap:12, padding:'10px 14px',
                  background:'rgba(14,20,52,0.50)',
                  borderBottom:`1px solid ${T.border}`, flexShrink:0,
                }}>
                  {/* Avatar placeholder */}
                  <div style={{
                    width:46, height:46, borderRadius:8, flexShrink:0, overflow:'hidden',
                    border:`1.5px solid ${T.border}`,
                    background:'rgba(20,30,70,0.9)', display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:22,
                  }}>🙂</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:13, fontWeight:800, color:T.text }}>Playing as: <span style={{ color:T.text }}>gamebee</span></div>
                    <div style={{ fontSize:10, color:T.textOwner, fontWeight:700 }}>(Owner)</div>
                    <div style={{ fontSize:10, color:T.textSub, marginTop:1, fontFamily:'JetBrains Mono,monospace' }}>Executor: Delta v1.1.702.622</div>
                    <div style={{ fontSize:10, color:T.textSub, fontFamily:'JetBrains Mono,monospace' }}>Script: CapybaraScripts Hub  ·  v690</div>
                  </div>
                </div>

                {/* Content scroll */}
                <div style={{ flex:1, overflowY:'auto', padding:'10px 12px', display:'flex', flexDirection:'column', gap:8 }}>
                  {activeTab === 'combat'       && <CombatPanel />}
                  {activeTab === 'hitbox'       && <HitboxPanel />}
                  {activeTab === 'optimization' && <OptPanel />}
                  {activeTab === 'visual'       && <VisualPanel />}
                </div>
              </div>

              {/* ── Right Tab Sidebar ── */}
              <div style={{
                width:150, flexShrink:0, display:'flex', flexDirection:'column',
                borderLeft:`1.5px solid ${T.border}`,
                background:'rgba(16,22,58,0.75)',
                padding:'8px 7px', gap:6, overflowY:'auto',
              }}>
                {TABS.map(tab => {
                  const active = activeTab === tab.id
                  return (
                    <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
                      display:'flex', flexDirection:'column', alignItems:'center',
                      justifyContent:'center', gap:5,
                      padding:'10px 6px', borderRadius:10, cursor:'pointer',
                      background: active ? T.tabActive : T.tabBg,
                      border: `1.5px solid ${active ? T.borderActive : T.border}`,
                      color: active ? '#fff' : T.textSub,
                      transition:'all 0.18s ease',
                      boxShadow: active ? `0 0 16px rgba(60,100,220,0.35), inset 0 1px 0 rgba(255,255,255,0.08)` : 'none',
                      fontFamily:'inherit',
                      transform: active ? 'scale(1.02)' : 'scale(1)',
                    }}
                      onMouseEnter={e => { if(!active) e.currentTarget.style.background=T.tabHover }}
                      onMouseLeave={e => { if(!active) e.currentTarget.style.background=T.tabBg }}
                    >
                      <span style={{ fontSize:22, lineHeight:1 }}>{tab.icon}</span>
                      <span style={{ fontSize:10, fontWeight:700, textAlign:'center', lineHeight:1.2, letterSpacing:'0.2px' }}>{tab.label}</span>
                    </button>
                  )
                })}

                <div style={{ flex:1 }} />

                {/* Mini notif button in sidebar */}
                <button onClick={() => addNotif('Success','Feature enabled!','success')}
                  style={{
                    padding:'7px', borderRadius:8, cursor:'pointer',
                    background:'rgba(30,45,100,0.6)', border:`1px solid ${T.border}`,
                    color:T.textMuted, fontSize:10, fontWeight:600,
                    fontFamily:'inherit', transition:'all 0.15s',
                  }}
                  onMouseEnter={e => e.currentTarget.style.color=T.textSub}
                  onMouseLeave={e => e.currentTarget.style.color=T.textMuted}
                >🔔 Test</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Notification Stack ── */}
      <div style={{ position:'fixed', bottom:16, right:16, width:300, zIndex:300, display:'flex', flexDirection:'column-reverse' }}>
        {notifs.map(n => (
          <NotifToast key={n.id} notif={n} onDone={() => removeNotif(n.id)} />
        ))}
      </div>

      {/* ── Key System Modal ── */}
      {showKeySystem && (
        <KeySystemModal
          onSuccess={() => { setShowKeySystem(false); addNotif('CapybaraScripts Hub','Key accepted! Hub loaded successfully.','success') }}
          onClose={() => setShowKeySystem(false)}
        />
      )}

      {/* ── Bottom hint ── */}
      <div style={{
        position:'absolute', bottom:10, left:'50%', transform:'translateX(-50%)',
        fontSize:10, color:T.textMuted, zIndex:5, userSelect:'none', textAlign:'center',
      }}>
        Drag window to reposition  ·  Key: <span style={{ color:T.textAccent, fontFamily:'JetBrains Mono,monospace' }}>CAPYBARA-FREE-2025</span>  ·  Right-click keybind to clear
      </div>
    </div>
  )
}
